import { LightningElement, api } from 'lwc';

export default class OvcTree extends LightningElement {
    @api nodes;
}