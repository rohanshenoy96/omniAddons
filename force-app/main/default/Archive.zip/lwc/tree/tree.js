import { LightningElement, api } from 'lwc';

export default class Tree extends LightningElement {
    @api nodes;
}